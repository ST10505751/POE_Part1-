/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatappst10505751;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Student
 */
public class ChatappST10505751 {
    
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner (System.in);
        ArrayList<Login> users = new ArrayList<>(); //Store multiple users
        
        System.out.println("Welcome to Chat App!Please select an option.");
        
        while (true){
            //Show menu after each action
            System.out.println("\nMain Menu:");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Select an option:");
                  
            int choice = scanner.nextInt();
            scanner.nextLine();//Consume newline
            
            switch (choice) {
                case 1:// Registration
                    System.out.print("Enter username: ");
                    String username = scanner.nextLine();
                    System.out.println("Username successfully captured");
                    //Validate username
                    boolean validUsername = username.contains("_") && username.length()<=5;
                    if(!validUsername){
                        System.out.print("Username is not correctly formatted; please ensure that your contains at least an underscore(_) and is no more than five characters in length");
                        break;
                    }
                        
                    System.out.print("Enter password: ");
                    String password = scanner.nextLine();
                    System.out.println("Password successfully captured");
                                        
                    //Validate password
                    boolean validPassword = password.length()>=8 &&
                                            password.matches(".*[A-Z].*") &&
                                            password.matches(".*\\d.*") &&
                                            password.matches(".*[!@#$%^&*(),.?\":{}|<>].*");
                            
                    if(!validPassword){
                    System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
                    break;
                    }
                    
                    System.out.println("Enter South African cellphone number(e.g. +27826557895): ");
                    String phoneNumber = scanner.nextLine();
                    System.out.println("Cellphone number successfully added.");
                    
                    //Validate Cellphone number
                    String regex = "\\+27[6-8]\\d(8)";
                    if (!phoneNumber.matches(regex)){
                       System.out.println("Cell phone number incorrectly formatted or does not contain international code. Use +27xxxxxxxxx.");
                       break;
                    } 
                    
                    //Check if username already exist
                    
                    boolean userExists = users.stream().anyMatch(u-> u.getUsername().equals(username));
                    if (userExists){
                    System.out.println("Username already exists. Please Create another username.");
                    break;
                    }
                    
                    //Add the new user
                    users.add(new Login(username, password, phoneNumber));
                    System.out.println("User registered successfully!");
                    
                    //Welcome the user and goes to login page
                    System.out.println("Welcome " + username + "! You can now log in.");
                    System.out.print("Redirecting to login page...\n");
                    
                    // Immediately prompt the user to login
                    promptLogin(scanner, users);
                    break;
                    
                case 2://login
                    if(users.isEmpty()){
                       System.out.println("No users registered yet. Please register first");
                       break;   
                    }
                    //Prompt the user to login
                    promptLogin(scanner, users);
                    break;
                    
                case 3: //Exit 
                    System.out.println("Goodbye!");
                    scanner.close();
                    return;
                    
                default:
                    System.out.println("Invalid option. Please choose option 1, 2, or 3.");               
            }
        }
    }
    //Method to handle login logic
    private static void promptLogin(Scanner scanner, ArrayList<Login> users){
        System.out.print("Enter username: ");
        String enteredUsername = scanner.nextLine();
        System.out.print("Enter password: ");
        String enteredPassword = scanner.nextLine();
        
        //Find user and try login
        Login user = users.stream()
                          .filter(u-> u.getUsername().equals(enteredUsername))
                          .findFirst()
                          .orElse(null);
        
        boolean loginStatus = user != null && user.loginUser(enteredPassword);
        System.out.println(user != null? user.returnLoginStatus(loginStatus): "User not found.");
       }           
    }
// Login class
class Login{
    public String username;
    public String passwordHash;
    public String phoneNumber;
    public byte[]salt;
    
    public Login(String username, String password, String phoneNumber){
        this.username = username;
        this.salt = generateSalt();
        this.passwordHash = hashPassword(password,salt);
        this.phoneNumber = phoneNumber;
    }
    public String getUsername(){
        return username;
    }
    public boolean loginUser(String enteredPassword){
        return this.passwordHash.equals(hashPassword(enteredPassword, salt));
    }
    public String returnLoginStatus(boolean status){
        return status?"Login successful! ": "ïnvalid username or password.";
    }
    //hash password with salt using SHA-256
    private String hashPassword(String password, byte[]salt){
        try{
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt);//add salt to the hash
            byte[]hash=md.digest(password.getBytes());
            StringBuilder hexString= new StringBuilder();
            for(byte b: hash){
               hexString.append(String.format("%02x", b));
        
            }
            return hexString.toString();   
        }catch(NoSuchAlgorithmException e){
            throw new RuntimeException("Error hashing password", e);
        }
    
    }
    //Geneate a random salt for password hashing
    private byte[]generateSalt(){
       try{
           SecureRandom random = new SecureRandom();
           byte[]salt = new byte[16];
           random.nextBytes(salt);
           return salt;
    }catch (Exception e){
       throw new RuntimeException("Error generating salt");
       }
    }
}

    